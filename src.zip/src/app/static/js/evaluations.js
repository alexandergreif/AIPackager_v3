document.addEventListener('DOMContentLoaded', () => {
    const modelSelector = document.getElementById('model-selector');
    const scenarioSelector = document.getElementById('scenario-selector');
    const evaluationForm = document.getElementById('evaluation-form');
    const startEvaluationBtn = document.getElementById('start-evaluation-btn');
    const evaluationSpinner = document.getElementById('evaluation-spinner');
    const progressBar = document.getElementById('progress-bar');
    const progressText = document.getElementById('progress-text');
    const evaluationError = document.getElementById('evaluation-error');
    const resultsContainer = document.getElementById('evaluation-results-container');
    const pastEvaluationsTable = document.getElementById('past-evaluations-table');

    const newEvaluationModal = document.getElementById('new-evaluation-modal');
    const openEvaluationModalBtn = document.getElementById('open-evaluation-modal-btn');
    const newEvaluationModalCloseBtn = document.getElementById('new-evaluation-modal-close-btn');

    const selectAllModelsBtn = document.getElementById('select-all-models');
    const deselectAllModelsBtn = document.getElementById('deselect-all-models');
    const selectAllScenariosBtn = document.getElementById('select-all-scenarios');
    const deselectAllScenariosBtn = document.getElementById('deselect-all-scenarios');

    const detailsModal = document.getElementById('evaluation-details-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalBody = document.getElementById('modal-body');
    const modalCloseBtn = document.getElementById('modal-close-btn');

    const api = {
        getModels: () => fetch('/api/evaluations/models').then(res => res.json()),
        getScenarios: () => fetch('/api/evaluations/scenarios').then(res => res.json()),
        getEvaluations: () => fetch('/api/evaluations').then(res => res.json()),
        getEvaluationLog: (logPath) => fetch(`/api/evaluations/logs?path=${encodeURIComponent(logPath)}`).then(res => res.text()),
        runEvaluation: (model_ids, scenario_ids) => fetch('/api/evaluations/run', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ model_ids, scenario_ids }),
        }).then(res => res.json()),
    };
    const socket = io();

    function createCard(item, type) {
        const card = document.createElement('div');
        card.className = `glass-card p-4 ${type}-card cursor-pointer flex items-start`;
        
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.className = 'mr-4 mt-1 h-4 w-4 text-accent-purple bg-secondary-bg border-border-color rounded focus:ring-accent-purple';
        checkbox.dataset.id = item.id;
        checkbox.dataset.type = type;

        const content = document.createElement('div');
        content.innerHTML = `
            <h4 class="font-bold text-text-primary">${item.name || item.title}</h4>
            <p class="text-sm text-text-secondary">${item.description || `Category: ${item.category}`}</p>
        `;

        card.appendChild(checkbox);
        card.appendChild(content);

        card.addEventListener('click', (e) => {
            if (e.target !== checkbox) {
                checkbox.checked = !checkbox.checked;
            }
            card.classList.toggle('selected', checkbox.checked);
            updateButtonState();
        });

        return card;
    }

    function getSelectedIds(type) {
        const selector = type === 'model' ? modelSelector : scenarioSelector;
        return Array.from(selector.querySelectorAll(`input[type="checkbox"]:checked`)).map(cb => cb.dataset.id);
    }

    function updateButtonState() {
        const selectedModels = getSelectedIds('model');
        const selectedScenarios = getSelectedIds('scenario');
        startEvaluationBtn.disabled = !(selectedModels.length > 0 && selectedScenarios.length > 0);
    }

    async function loadInitialData() {
        const [models, scenarios, evaluations] = await Promise.all([
            api.getModels(),
            api.getScenarios(),
            api.getEvaluations(),
        ]);

        models.forEach(model => modelSelector.appendChild(createCard(model, 'model')));
        scenarios.forEach(scenario => scenarioSelector.appendChild(createCard(scenario, 'scenario')));
        renderPastEvaluations(evaluations);
        updateButtonState();
    }

    function renderPastEvaluations(evaluations) {
        pastEvaluationsTable.innerHTML = '';
        if (evaluations.length === 0) {
            pastEvaluationsTable.innerHTML = '<tr><td colspan="5" class="text-center py-4 text-text-secondary">No past evaluations found.</td></tr>';
            return;
        }
        evaluations.forEach(e => {
            const row = document.createElement('tr');
            row.className = 'border-b border-border-color';
            row.innerHTML = `
                <td class="px-6 py-4 whitespace-nowrap text-text-primary">${e.model.name}</td>
                <td class="px-6 py-4 whitespace-nowrap text-text-primary">${e.scenario.title}</td>
                <td class="px-6 py-4 whitespace-nowrap text-text-primary">${e.metrics.trust_score.toFixed(2)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-text-secondary">${new Date(e.timestamp).toLocaleString()}</td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button data-id="${e.id}" class="view-details-btn text-accent-blue hover:underline">View</button>
                </td>
            `;
            pastEvaluationsTable.appendChild(row);
        });
    }

    function renderEvaluationResult(result, logContent = null) {
        const formatReport = (title, report, isCorrection = false) => {
            if (!report || report.length === 0) {
                return `<div><h4 class="font-semibold text-accent-green mb-2">${title}</h4><p class="text-sm text-text-secondary">None</p></div>`;
            }
            return `
                <div>
                    <h4 class="font-semibold text-accent-green mb-2">${title}</h4>
                    <ul class="space-y-3">
                        ${report.map(item => `
                            <li class="text-sm text-text-secondary border-l-2 border-border-color pl-3">
                                <strong class="text-text-primary">${isCorrection ? 'Correction' : item.type}:</strong> ${isCorrection ? item.original : (item.text || 'N/A')}
                                <pre class="bg-secondary-bg p-2 rounded mt-1 text-xs font-mono whitespace-pre-wrap">${isCorrection ? `Reason: ${item.reason}` : (item.description || 'No description')}</pre>
                            </li>
                        `).join('')}
                    </ul>
                </div>
            `;
        };

        const logHtml = logContent ? `<pre class="bg-secondary-bg p-3 rounded text-sm whitespace-pre-wrap font-mono text-text-secondary h-64 overflow-y-auto">${logContent}</pre>` : `<p class="text-sm text-text-secondary">Log not available.</p>`;

        return `
            <div class="glass-card p-6 mb-4">
                <h3 class="text-xl font-semibold text-accent-green mb-4">Result for ${result.model.name} on "${result.scenario.title}"</h3>
                
                <!-- Metrics -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <div class="glass-card p-4 text-center">
                        <p class="text-sm text-text-secondary">Hallucinations Found</p>
                        <p class="text-2xl font-bold text-text-primary">${result.metrics.hallucinations_found}</p>
                    </div>
                    <div class="glass-card p-4 text-center">
                        <p class="text-sm text-text-secondary">Hallucinations Corrected</p>
                        <p class="text-2xl font-bold text-text-primary">${result.metrics.hallucinations_corrected}</p>
                    </div>
                    <div class="glass-card p-4 text-center">
                        <p class="text-sm text-text-secondary">Trust Score</p>
                        <p class="text-2xl font-bold text-text-primary">${result.metrics.trust_score.toFixed(2)}</p>
                    </div>
                </div>

                <!-- Two-column layout for details -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Left Column: Outputs -->
                    <div class="space-y-4">
                        <div>
                            <h4 class="font-semibold text-accent-green mb-2">Raw Model Output</h4>
                            <pre class="bg-secondary-bg p-3 rounded text-sm whitespace-pre-wrap text-text-secondary font-mono h-48 overflow-y-auto">${result.raw_model_output}</pre>
                        </div>
                        <div>
                            <h4 class="font-semibold text-accent-green mb-2">Advisor Corrected Output</h4>
                            <pre class="bg-green-900 bg-opacity-20 p-3 rounded text-sm whitespace-pre-wrap text-green-300 font-mono h-48 overflow-y-auto">${result.advisor_corrected_output}</pre>
                        </div>
                    </div>

                    <!-- Right Column: Reports -->
                    <div class="space-y-4">
                        ${formatReport('Detected Hallucinations', result.detailed_hallucination_report)}
                        ${formatReport('Applied Corrections', result.detailed_corrections_log, true)}
                    </div>
                </div>

                <!-- Full Log Section -->
                <div class="mt-6 full-log-container">
                    <h4 class="font-semibold text-accent-green mb-2">Full Evaluation Log</h4>
                    ${logHtml}
                </div>
            </div>
        `;
    }

    evaluationForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        evaluationSpinner.classList.remove('hidden');
        evaluationError.classList.add('hidden');
        startEvaluationBtn.disabled = true;
        progressBar.style.width = '0%';
        progressText.textContent = '';

        const selectedModelIds = getSelectedIds('model');
        const selectedScenarioIds = getSelectedIds('scenario');
        const totalRuns = selectedModelIds.length * selectedScenarioIds.length;
        let completedRuns = 0;

        // This is a simplified progress simulation.
        // A real implementation would use WebSockets for real-time progress.
        resultsContainer.innerHTML = '';
        let allResults = [];

        socket.on('evaluation_progress', (data) => {
            progressBar.style.width = `${data.progress}%`;
            progressText.textContent = data.status;

            if (data.result) {
                allResults.push(data.result);
                resultsContainer.innerHTML += renderEvaluationResult(data.result);
            }
            if (data.error) {
                evaluationError.textContent += `\n${data.error}`;
                evaluationError.classList.remove('hidden');
            }
        });

        socket.on('evaluation_complete', async (data) => {
            progressText.textContent = data.message;
            evaluationSpinner.classList.add('hidden');
            startEvaluationBtn.disabled = false;
            hideNewEvaluationModal();
            
            // Fetch full logs for all results now that the process is complete
            for (let i = 0; i < allResults.length; i++) {
                const logContent = await api.getEvaluationLog(allResults[i].evaluation_log);
                const resultElement = resultsContainer.children[i];
                const logContainer = resultElement.querySelector('.full-log-container');
                if (logContainer) {
                    logContainer.innerHTML = `<pre class="bg-secondary-bg p-3 rounded text-sm whitespace-pre-wrap font-mono text-text-secondary h-64 overflow-y-auto">${logContent}</pre>`;
                }
            }

            const evaluations = await api.getEvaluations();
            renderPastEvaluations(evaluations);

            // Clean up listeners
            socket.off('evaluation_progress');
            socket.off('evaluation_complete');
        });

        try {
            const response = await api.runEvaluation(selectedModelIds, selectedScenarioIds);
            if (response.error) {
                throw new Error(response.error);
            }
        } catch (err) {
            evaluationError.textContent = `Error: ${err.message}`;
            evaluationError.classList.remove('hidden');
            evaluationSpinner.classList.add('hidden');
            startEvaluationBtn.disabled = false;
            socket.off('evaluation_progress');
            socket.off('evaluation_complete');
        }
    });

    function showDetailsModal(evaluation, logContent) {
        modalTitle.textContent = `Details for ${evaluation.model.name} on "${evaluation.scenario.title}"`;
        modalBody.innerHTML = renderEvaluationResult(evaluation, logContent);
        detailsModal.classList.remove('hidden');
        detailsModal.classList.add('flex');
    }

    function hideDetailsModal() {
        detailsModal.classList.add('hidden');
        detailsModal.classList.remove('flex');
    }

    function showNewEvaluationModal() {
        newEvaluationModal.classList.remove('hidden');
        newEvaluationModal.classList.add('flex');
    }

    function hideNewEvaluationModal() {
        newEvaluationModal.classList.add('hidden');
        newEvaluationModal.classList.remove('flex');
    }

    pastEvaluationsTable.addEventListener('click', async (event) => {
        if (event.target.classList.contains('view-details-btn')) {
            const id = event.target.dataset.id;
            const evaluations = await api.getEvaluations();
            const evaluation = evaluations.find(e => e.id === id);
            if (evaluation) {
                const logContent = await api.getEvaluationLog(evaluation.evaluation_log);
                showDetailsModal(evaluation, logContent);
            }
        }
    });

    openEvaluationModalBtn.addEventListener('click', showNewEvaluationModal);
    newEvaluationModalCloseBtn.addEventListener('click', hideNewEvaluationModal);
    modalCloseBtn.addEventListener('click', hideDetailsModal);

    selectAllModelsBtn.addEventListener('click', () => {
        modelSelector.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = true);
        updateButtonState();
    });
    deselectAllModelsBtn.addEventListener('click', () => {
        modelSelector.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = false);
        updateButtonState();
    });
    selectAllScenariosBtn.addEventListener('click', () => {
        scenarioSelector.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = true);
        updateButtonState();
    });
    deselectAllScenariosBtn.addEventListener('click', () => {
        scenarioSelector.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = false);
        updateButtonState();
    });
    
    newEvaluationModal.addEventListener('click', (event) => {
        if (event.target === newEvaluationModal) {
            hideNewEvaluationModal();
        }
    });
    detailsModal.addEventListener('click', (event) => {
        if (event.target === detailsModal) {
            hideDetailsModal();
        }
    });

    loadInitialData();
});
